return {
    {
        "saghen/blink.compat",
        opts = {},
    },
}
