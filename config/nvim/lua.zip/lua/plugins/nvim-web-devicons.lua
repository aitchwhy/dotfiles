return {
    { "nvim-tree/nvim-web-devicons", opts = {} },
}
