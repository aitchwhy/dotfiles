return {

    -- SURROUND: manipulate surrounding characters
    { "kylechui/nvim-surround", event = "VeryLazy", config = true }, -- uses default setup

}
