return {
    -- add blink.compat to dependencies
    {
        "rafamadriz/friendly-snippets",
    },
}
