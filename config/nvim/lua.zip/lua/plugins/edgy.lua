return {
    {
        "folke/edgy.nvim",
        event = "VeryLazy",
        opts = {},
    },
}
