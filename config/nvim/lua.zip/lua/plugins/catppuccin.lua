return {
    {
        "catppuccin",
        opts = {
            integrations = { blink_cmp = true },
        },
    },
}
