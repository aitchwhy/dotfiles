---
categories:
  - "[[People]]"
type:
  - "[[Musicians]]"
created: 2023-09-13
---
## Albums

![[Albums.base#Artist]]