---
categories:
  - "[[Places]]"
type:
  - "[[Cities]]"
loc:
  - "[[Japan]]"
coordinates:
  - "35.021041"
  - "135.7556075"
rating: 7
created: 2023-09-12
---
## Trips

![[Trips.base#Location]]

## Places

![[Map.base#Location]]
![[Places.base#Location]]