---
categories:
  - "[[Albums]]"
genre:
  - "[[Jazz]]"
artist: "[[Paul Chambers]]"
year: 1957
rating: 7
created: 2023-09-12
---

