---
categories:
  - "[[People]]"
type:
  - "[[Authors]]"
org:
  - "[[Obsidian]]"
created: 2023-09-12
twitter: kepano
url: https://stephango.com/
---
## Clippings

![[Clippings.base#Author]]

## Meetings

![[Meetings.base#Person]]