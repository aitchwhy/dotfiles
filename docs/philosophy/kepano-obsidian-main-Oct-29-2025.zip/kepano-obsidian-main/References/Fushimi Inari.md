---
categories:
  - "[[Places]]"
type:
  - "[[Parks]]"
  - "[[Shrines]]"
loc:
  - "[[Kyoto]]"
  - "[[Japan]]"
rating: 7
created: 2023-09-12
coordinates:
  - "34.9689499"
  - "135.7692576"
---
