---
categories:
  - "[[Podcast episodes]]"
show: "[[Well Made]]"
guests:
  - "[[Kevin Kelly]]"
topics: []
episode: "145"
rating: 7
published: 2021-04-15
last: 2023-09-12
---
