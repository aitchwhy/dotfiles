---
categories:
  - "[[People]]"
type:
  - "[[Authors]]"
created: 2023-09-12
---
## Books

![[Books.base#Author]]

# Clippings

![[Clippings.base#Author]]

# Podcast episodes

![[Podcast episodes.base#Guest]]