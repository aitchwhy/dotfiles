---
categories:
  - "[[Books]]"
cover: "[[out-of-control.jpg]]"
isbn: 201483408
isbn13: 9780201483406
pages: 528
year: 1992
author:
  - "[[Kevin Kelly]]"
genre:
  - "[[Futurism]]"
  - "[[Nonfiction]]"
topics:
  - "[[Emergence]]"
created: 2023-09-12
last: 2023-09-12
rating: 7
---
