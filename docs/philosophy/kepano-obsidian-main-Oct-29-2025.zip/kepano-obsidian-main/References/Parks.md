---
tags:
  - places/types
icon: trees
color: green
---

## Places

![[Map.base#Type]]
![[Places.base#Type]]