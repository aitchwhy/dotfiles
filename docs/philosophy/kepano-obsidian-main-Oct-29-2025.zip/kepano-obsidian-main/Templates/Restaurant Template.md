---
categories:
  - "[[Places]]"
type:
  - "[[Restaurants]]"
loc:
rating:
created:
  "{ date }":
last:
  "{ date }":
---
