---
categories: "[[People]]"
type:
  - "[[Authors]]"
---
## Books

![[Books.base#Author]]