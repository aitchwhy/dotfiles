---
categories:
  - "[[Quotes]]"
attribution: []
source:
created:
  "{ date }":
topics: []
via:
---
