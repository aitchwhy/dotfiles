---
categories:
  - "[[Board games]]"
type: []
maker:
year:
rating:
last: {{date}}
---
