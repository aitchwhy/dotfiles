---
tags:
  - movies/genres
---
![[Movies.base#Genre]]