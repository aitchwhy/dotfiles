---
categories:
  - "[[Places]]"
type: []
address:
rating:
created: {{date}}
url:
year:
price:
sqft:
lotsqft:
loc: []
status:
---
