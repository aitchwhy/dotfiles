---
tags:
  - meetings/type
---
![[Meetings.base#Type]]