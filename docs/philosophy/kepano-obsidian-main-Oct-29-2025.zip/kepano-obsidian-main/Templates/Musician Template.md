---
categories: "[[People]]"
type:
  - "[[Musicians]]"
created: {{date}}
---
## Albums

![[Albums.base#Artist]]