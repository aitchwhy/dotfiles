---
categories: "[[People]]"
type:
  - "[[Actors]]"
---
## Movies

![[Movies.base#Actor]]