---
categories:
  - "[[Movies]]"
cover:
genre: []
director:
cast: []
runtime:
rating:
year:
last: {{date}}
imdbId:
via:
---

