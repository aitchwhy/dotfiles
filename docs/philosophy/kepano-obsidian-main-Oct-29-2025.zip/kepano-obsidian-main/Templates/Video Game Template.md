---
categories:
  - "[[Games]]"
maker:
genre: []
year:
system:
rating:
created: {{date}}
last: {{date}}
---
