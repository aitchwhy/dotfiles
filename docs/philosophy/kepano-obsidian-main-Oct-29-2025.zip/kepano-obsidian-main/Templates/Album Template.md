---
categories:
  - "[[Albums]]"
genre: []
artist: ""
year:
created:
  "{ date }":
rating:
---

