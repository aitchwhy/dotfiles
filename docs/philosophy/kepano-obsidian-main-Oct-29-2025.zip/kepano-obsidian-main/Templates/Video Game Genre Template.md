---
tags:
  - games/genres
---
![[Games.base#Genre]]