---
date: {{date}}
trade: 
tags:
  - investment
  - trade
price: 
shares:
---
