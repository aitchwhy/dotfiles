---
categories:
  - "[[People]]"
type:
  - "[[Directors]]"
created: {{date}}
---
## Movies

![[Movies.base#Director]]