---
categories:
  - "[[People]]"
birthday:
org: []
created: {{date}}
---
## Meetings

![[Meetings.base#Person]]