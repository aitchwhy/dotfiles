---
categories:
  - "[[Places]]"
type:
  - "[[Cities]]"
loc:
rating:
created: {{date}}
last:
coordinates:
  - "35.021041"
  - "135.7556075"
---
## Trips

![[Trips.base#Location]]

## Places

![[Map.base#Location]]

![[Places.base#Location]]