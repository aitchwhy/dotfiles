---
categories:
  - "[[Recipes]]"
cuisine:
type: []
ingredients:
author: []
url:
rating:
created:
  "{ date }":
last:
  "{ date }":
---
## Ingredients

- 

## Directions

- 

## Notes

- 