---
categories:
  - "[[Food]]"
maker:
rating:
price:
last: {{date}}
created: {{date}}
---
