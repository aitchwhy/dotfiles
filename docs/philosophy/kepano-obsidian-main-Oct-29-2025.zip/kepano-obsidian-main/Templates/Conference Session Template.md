---
categories: 
  - "[[Conference sessions]]"
conference: 
speaker: 
topics: []
rating: 
last: {{date}}
tags:
  - conferences
  - sessions
  - events
---
