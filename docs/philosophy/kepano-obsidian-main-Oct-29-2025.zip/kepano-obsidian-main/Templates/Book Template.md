---
categories:
  - "[[Books]]"
author: []
cover:
genre: []
pages:
isbn:
isbn13:
year:
rating:
topics: []
created: {{date}}
last:
via: ""
tags:
  - to-read
---
