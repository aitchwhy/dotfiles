---
categories:
  - "[[Meetings]]"
type: []
date: 2023-09-14
org:
  - "[[Obsidian]]"
loc:
  - Remote
people:
  - "[[Steph Ango]]"
topics:
  - "[[Emergence]]"
---
- Discussed the book [[Out of Control]] on the topic of [[Emergence]]