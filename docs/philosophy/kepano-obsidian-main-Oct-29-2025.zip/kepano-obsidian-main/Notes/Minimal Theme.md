---
categories:
  - "[[Projects]]"
type:
  - "[[UI]]"
org:
  - "[[Obsidian]]"
year: 2020
url: https://minimal.guide
status:
  - "[[Active]]"
---
## To-do

- [x] Color schemes
- [x] E-ink mode
- [x] Mobile support