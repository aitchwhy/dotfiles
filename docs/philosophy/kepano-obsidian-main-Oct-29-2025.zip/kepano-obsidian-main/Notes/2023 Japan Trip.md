---
categories:
  - "[[Trips]]"
start: 2023-09-12
end: 2023-09-30
loc:
  - "[[Kyoto]]"
  - "[[Japan]]"
---

