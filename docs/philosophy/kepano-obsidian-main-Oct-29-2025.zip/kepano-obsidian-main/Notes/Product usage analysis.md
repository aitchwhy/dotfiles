Analysis of cost per use, see [[Buy wisely]]

![[Products.base#Cost per use]]