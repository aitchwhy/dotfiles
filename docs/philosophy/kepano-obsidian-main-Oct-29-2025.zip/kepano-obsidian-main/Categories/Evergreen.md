---
tags:
  - categories
---
An evergreen note is an idea. It doesn't have to be something that I agree with, but something is [[Composability|composable]]. In a way, every idiom is a kind of evergreen idea.

![[Evergreen.base]]